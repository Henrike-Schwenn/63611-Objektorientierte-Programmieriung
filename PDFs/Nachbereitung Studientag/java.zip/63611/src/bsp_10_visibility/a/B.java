package bsp_10_visibility.a;

public class B {
    A a;
    
    void test() {
        System.out.println(a.publicMethod());
        System.out.println(a.protectedMethod());
        System.out.println(a.defaultMethod());
        System.out.println(a.privateMethod());
    }
}
