package bsp_10_visibility.a.a;

import bsp_10_visibility.a.A;

public class C {
    
    A a;
    
    void test() {
        System.out.println(a.publicMethod());
        System.out.println(a.protectedMethod());
        System.out.println(a.defaultMethod());
        System.out.println(a.privateMethod());
    }
}
