package bsp_10_visibility.a;

public class A {
    
    A a;
    
    public int publicMethod() {
        return 42;
    }

    protected int protectedMethod() {
        return 42;
    }

    int defaultMethod() {
        return 42;
    }

    private int privateMethod() {
        return 42;
    }
    
    void test() {
        System.out.println(a.publicMethod());
        System.out.println(a.protectedMethod());
        System.out.println(a.defaultMethod());
        System.out.println(a.privateMethod());
    }
}