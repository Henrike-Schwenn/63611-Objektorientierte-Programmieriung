package bsp_22_inner_outer;
public class TricksWithInterfaces {
    public static void main(String[] args) {
        CarFactory factory = CarFactory.getSingleInstance();
        Car myNewCar = factory.giveMeACar();
        System.out.println(myNewCar.readMotorPowerInKiloWatt());

        // Was der Besitzer nun möchte:, was aber nicht geht, weil er sein Auto ja nur als Car kennt, nicht als RealCar:
        myNewCar.tunePower();

        // Was er probiert, um das zu ändern (man beachte die Fehlermeldung des Compilers)
        RealCar myCarAsRealCar = (RealCar) myNewCar;
        myCarAsRealCar.tunePower();

        // Das akzeptiert der Compiler, aber...
        factory.tuneMyCar(myNewCar, 2000);
        System.out.println(myNewCar.readMotorPowerInKiloWatt());

        // Da bleibt ihm nur:
        factory.tuneMyCar(myNewCar, 6000);
        System.out.println(myNewCar.readMotorPowerInKiloWatt());
    }
}

// CarFactory als Singleton mit lazy initialisation, Näheres dazu siehe z.B. hier:
// http://www.theserverside.de/singleton-pattern-in-java/
class CarFactory {

    // Hier merkt sich die Klasse ihre einzige Instanz
    private static CarFactory singleInstance;

    // privater Konstruktor, damit niemand von außen eine CarFactory erzeugen kann
    private CarFactory() {
    }

    // Methode, mit der man eine Referenz auf die einzige existierende CarFactory erhalten kann
    public static synchronized CarFactory getSingleInstance() {
        if (singleInstance == null) {
            singleInstance = new CarFactory();
        }
        return singleInstance;
    }

    // Rückgabetyp der Methode ist der Interfacetyp, nicht die Klasse!
    public Car giveMeACar() {
        return new RealCar(98);
    }

    public void tuneMyCar(Car car, int greatAmountOfMoney) {
        if (greatAmountOfMoney < 5000) {
            System.out.println("Factory: Für " + greatAmountOfMoney + "? Träum weiter!");
        } else {
            System.out.println("Factory: Ok, Chef, machen wir.");
            // Den folgenden Cast kann nur die Fabrik ausführen, denn RealCar ist private innere Klasse von CarFactory
            RealCar realCar = (RealCar) car;
            realCar.tunePower();
        }
    }

    private static class RealCar implements Car {
        private double power;

        public RealCar(double power) {
            this.power = power;
        }

        @Override
        public String readMotorPowerInKiloWatt() {
            return "Car: My power is " + power + " KW!";
        }

        // Diese Methode kann nur jemand ausführen, der das Auto als Instanz seiner Klasse kennt.
        // Wer nur das Interface hat, kann das nicht, weil sie dort nicht vorkommt.
        public void tunePower() {
            power = power * 1.2;
        }
    }
}

// Interface, welches nur genau den Teil der Methodenschnttstelle eines RealCar enthält, welche die Factory dem Besitzer
// zugänglich machen möchte
interface Car {
    String readMotorPowerInKiloWatt();
}
