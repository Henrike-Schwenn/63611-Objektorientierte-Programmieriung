package bsp_22_inner_outer;

public class Test {
    public static void main(String[] args) {
        // Erzeugen eines Outer
        Outer outer = new Outer();

        // spezielle Syntax, um einem Inner bei der Erzeugung "sein" Outer mitzuteilen.
        Outer.Inner inner = outer.new Inner();

        inner.m();

    }
}

class Outer {

    private String x = "Attribut x eines Outer";

    private String y = "Attribut y eines Outer";

    class Inner {

        private String y = "Attribut y eines Inner";

        void m() {
            // Zugriff auf das Attribut x des "umgebenden Outer"
            System.out.println(x);

            // Zugriff auf y meint das Attribut von this, also das eines Inner,
            // denn dieses verdeckt das gleichnamige Attribut des "umgebenden Outer".
            System.out.println(y);

            // Zugriff auf das verdeckte Attribut y des "umgebenden Outer"
            // ist durch eine spezielle Syntax möglich
            System.out.println(Outer.this.y);
        }
    }

    static class StaticInner {
        void m() {
            // Es existiert kein "umgebendes Outer" -> Compilerfehler
            System.out.println(x);
        }
    }
}