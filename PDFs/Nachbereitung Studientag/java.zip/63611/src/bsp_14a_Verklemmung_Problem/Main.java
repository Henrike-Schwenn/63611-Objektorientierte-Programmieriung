package bsp_14a_Verklemmung_Problem;

public class Main {
    public static void main(String[] args) {
        Konto k1 = new Konto(1000);
        Konto k2 = new Konto(1000);
        Thread t1 = new UmbuchungsThread(k1, k2, 100);
        Thread t2 = new UmbuchungsThread(k2, k1, 1100);
        t1.start();
        t2.start();
        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Kontostand k1: " + k1.getSaldo());
        System.out.println("Kontostand k2: " + k2.getSaldo());
    }
}

class UmbuchungsThread extends Thread {

    private Konto von;

    private Konto ziel;

    private int betrag;

    public UmbuchungsThread(Konto von, Konto ziel, int betrag) {
        this.von = von;
        this.ziel = ziel;
        this.betrag = betrag;
    }

    @Override
    public void run() {
        von.umbuchenAuf(ziel, betrag);
    }
}

class Konto {
    private int saldo;

    Konto(int startSaldo) {
        saldo = startSaldo;
    }

    public int getSaldo() {
        return saldo;
    }

    public synchronized void umbuchenAuf(Konto ziel, int betrag) {
        try {
            Thread.sleep(50);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        synchronized (ziel) {
            this.saldo = this.saldo - betrag;
            ziel.saldo = ziel.saldo + betrag;
        }
    }
}