package bsp_09_polymorphie;

public class C1_BeschraenkteParametrischePolymorphie {
    public static void main(String[] args) {
        ContainerC1<Integer> c = new ContainerC1<Integer>();
        c.store(new Integer(3));
        c.store(new Integer(42));
        c.store(new Integer(-7));
        Integer maxElem = c.get();
        System.out.println(maxElem);
    }
}

// Ein Container, der sich nur das "groesste" der Objekte
// merkt, die hineingetan wurden
class ContainerC1<T> {
    private T element;

    public void store(T o) {
        if (element == null || o.compareTo(element) > 0) {
            element = o;
        }
    }

    public T get() {
        return element;
    }
}