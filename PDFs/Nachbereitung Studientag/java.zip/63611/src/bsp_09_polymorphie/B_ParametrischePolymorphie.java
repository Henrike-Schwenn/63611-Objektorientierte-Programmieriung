package bsp_09_polymorphie;

public class B_ParametrischePolymorphie {
    public static void main(String[] args) {
        ContainerB<String> c = new ContainerB<String>();
        c.store("TestString");
        String s = c.get();
        System.out.println(s.charAt(0));
    }
}

class ContainerB<T> {
    private T element;

    public void store(T o) {
        element = o;
    }

    public T get() {
        return element;
    }
}
