package bsp_09_polymorphie;

public class A_SubtypPolymorphie {
    public static void main(String[] args) {
        ContainerA c = new ContainerA();
        c.store("TestString");
        String s = c.get();
        System.out.println(s.charAt(0));
    }
}

class ContainerA {
    private Object element;

    public void store(Object o) {
        element = o;
    }

    public Object get() {
        return element;
    }
}