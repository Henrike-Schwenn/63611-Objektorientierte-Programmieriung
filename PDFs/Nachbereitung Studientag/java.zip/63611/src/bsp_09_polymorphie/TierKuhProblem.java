package bsp_09_polymorphie;

public class TierKuhProblem {
    public static void main(String[] args) {

        // Wenn man für die Kuh keine eigenen Methoden und Eigenschaften benötigt,
        // muss man sie nicht als Subklasse von Tier modellieren, sondern es reicht,
        // eine
        // Instanz von Tier zu erzeugen und diese mit Gras als Nahrung zu
        // parametrisieren:
        Tier<Gras> kuh = new Tier<Gras>();

        // Benötigt man hingegen für die Kuh eigene Methoden und Eigenschaften,
        // wird man Kuh als Subklasse von Tier modellieren und die Belegung des
        // Typparameters
        // beim Subclassing vorzunehmen (siehe Klasse Kuh unten). Bei der Erzeugung
        // einer Instanz
        // der Klasse Kuh muss der Typparameter dann natürlich nicht noch einmal belegt
        // werden.
        Tier<Gras> tier = new Kuh();

        tier.friss(new Gras());
        tier.friss(new Schnitzel()); // Compilerfehler!
    }
}

// Durch den Typparameter haben wir jetzt KEINE Allaussage "Jedes Tier frisst beliebige Nahrung"
// mehr, sondern stattdessen die Aussage "Jedes Tier frisst einen bestimmten Subtyp von Nahrung",
// was der Realität entspricht.
class Tier<T extends Nahrung> {
    public void friss(T nahrung) {
        nahrung.kaueUndVerdaue();
    }
}

// Die Kuh frisst jetzt - durch den Compiler überprüft - nur noch Gras,
// trotzdem erbt sie die in Tier implementierte Methode "fressen". So soll es sein.
// Man beachte die Parallelen zu einer Redefintion mit kovariantem Parametertyp.
class Kuh extends Tier<Gras> {
    // Hier würde man Kuh-spezifische Methoden und Eigenschaften deklarieren.
}

class Nahrung {
    public void kaueUndVerdaue() {
    }
}

class Gras extends Nahrung {
}

class Schnitzel extends Nahrung {
}