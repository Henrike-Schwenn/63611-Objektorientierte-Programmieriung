package bsp_17_wildcards;

import java.util.*;

public class WildcardTest {
    public static void main(String[] args) {
        List<?> liste1 = null;
//        liste1.add(new Object());
//        liste1.add(new Tier());
//        liste1.add(new Vogel());
//        Object o1 = liste1.get(0);
//        Tier t1 = liste1.get(0);
//        Vogel v1 = liste1.get(0);

        List<? extends Tier> liste2 = null;
//        liste2.add(new Object());
//        liste2.add(new Tier());
//        liste2.add(new Vogel());
//        Object o2 = liste2.get(0);
//        Tier t2 = liste2.get(0);
//        Vogel v2 = liste2.get(0);

        List<? super Vogel> liste3 = null;
//        liste3.add(new Object());
//        liste3.add(new Tier());
//        liste3.add(new Vogel());
//        Object o3 = liste3.get(0);
//        Tier t3 = liste3.get(0);
//        Vogel v3 = liste3.get(0);
    }
}

class Tier {}

class Vogel extends Tier {}

class Amsel extends Vogel {}



