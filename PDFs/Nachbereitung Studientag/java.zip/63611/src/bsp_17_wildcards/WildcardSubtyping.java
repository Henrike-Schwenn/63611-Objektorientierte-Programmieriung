package bsp_17_wildcards;

import java.util.ArrayList;
import java.util.List;

public class WildcardSubtyping {
    public static void main(String[] args) {
        List<?> listA = null;
        List<Object> listB = null;
        List<? extends Object> listC = null;
        List<? super Object> listD = null;
        List<String> listE = null;

//        Welche der folgenden Zuweisungen sind *nicht* typkorrekt 
//        und werden deshalb vom Compiler zurückgewiesen?

//        listA = listB;
//        listA = listC;
//        listA = listD;
//        listA = listE;
////
//        listB = listA;
//        listB = listC;
//        listB = listD;
//        listB = listE;
////
//        listC = listA;
//        listC = listB;
//        listC = listD;
//        listC = listE;
////
//        listD = listA;
//        listD = listB;
//        listD = listC;
//        listD = listE;
    }
}
