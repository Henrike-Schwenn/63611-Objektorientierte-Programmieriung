package bsp_14b_Verklemmung_Loesung;

public class Main {
    public static void main(String[] args) {
        Konto k42 = new Konto(1000, 42);
        Konto k23 = new Konto(1000, 23);
        Thread t1 = new UmbuchungsThread(k42, k23, 100);
        Thread t2 = new UmbuchungsThread(k23, k42, 1100);
        t1.start();
        t2.start();
        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Kontostand k42: " + k42.getSaldo());
        System.out.println("Kontostand k23: " + k23.getSaldo());
    }
}

class UmbuchungsThread extends Thread {

    private Konto von;

    private Konto ziel;

    private int betrag;

    public UmbuchungsThread(Konto von, Konto ziel, int betrag) {
        this.von = von;
        this.ziel = ziel;
        this.betrag = betrag;
    }

    @Override
    public void run() {
        von.umbuchenAuf(ziel, betrag);
    }
}

class Konto {
    private final int kontoNummer;

    private int saldo;

    Konto(int startSaldo, int kontoNummer) {
        saldo = startSaldo;
        this.kontoNummer = kontoNummer;
    }

    public int getSaldo() {
        return saldo;
    }

    public void umbuchenAuf(Konto ziel, int betrag) {
        Konto kleiner = kontoNummer <= ziel.kontoNummer ? this : ziel;
        Konto groesser = kontoNummer > ziel.kontoNummer ? this : ziel;
        synchronized (kleiner) {
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            synchronized (groesser) {
                this.saldo = this.saldo - betrag;
                ziel.saldo = ziel.saldo + betrag;
                System.out.println("umgebucht von " + kontoNummer + " auf " + ziel.kontoNummer);
            }
        }
    }
}
