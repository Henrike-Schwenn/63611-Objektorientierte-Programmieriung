package bsp_12_exceptions;

public class Test_1 {
    public static void main(String[] args) throws OutOfBoundsException {

        Test_1 t = new Test_1();
        t.aMethod(2);

//        try {
//            t.aMethod(2);
//        } catch (OutOfBoundsException e) {
//            System.out.println("Catch Block für Typ OutOfBoundsException");
//            System.out.println(e);
//        } catch (Exception e) {
//            System.out.println("Catch Block für Typ Exception");
//            System.out.println(e);
//        } finally {
//            System.out.println("Finally-Block");
//        }
    }

    void aMethod(int v) throws OutOfBoundsException {
        if (v > 50 || v < 17) throw new OutOfBoundsException("Ungültiger Wert", v);
    }
}

class OutOfBoundsException extends Exception {

    private int value;

    public OutOfBoundsException(String message, int wert) {
        super(message);
        this.value = wert;
    }

    public int getValue() {
        return value;
    }

    @Override
    public String toString() {
        return getMessage() + ": " + value;
    }
}