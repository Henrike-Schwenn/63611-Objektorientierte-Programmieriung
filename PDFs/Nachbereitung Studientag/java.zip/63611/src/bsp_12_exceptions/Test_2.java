package bsp_12_exceptions;

public class Test_2 {
    public void m1() {
        try {
            System.out.println("Methode m1");
        } catch (OutOfBoundsException e) {
            e.printStackTrace();
        } 
    }
    
    public void m2() {
        try {
            throw new OutOfBoundsException("", 0);
        } catch (Exception e) {
            e.printStackTrace();
        } catch (OutOfBoundsException e) {
            e.printStackTrace();
        }
    }
}
