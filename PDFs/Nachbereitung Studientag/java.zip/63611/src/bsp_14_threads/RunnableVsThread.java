package bsp_14_threads;

class Worker1 extends Thread {
    @Override
    public void run() {
        // Hier kommt der "Job" hin, der in einem eigenen Thread erledigt werden soll
    }
}

class Worker2 extends FiktiveSuperKlasse implements Runnable {
    @Override
    public void run() {
        // Hier kommt der "Job" hin, der in einem eigenen Thread erledigt werden soll
    }
}

class FiktiveSuperKlasse {}

public class RunnableVsThread {
    public static void main(String[] args) {
        Thread t1 = new Worker1();
        t1.start();

        Thread t2 = new Thread(new Worker2());
        t2.start();
    }
}