package bsp_14_threads;

// Schon dieses minimale Beispiel kann in einem Szenario, in dem mehrere Threads auf demselbe Konto 
// dessen Methode einzahlen() aufrufen, dazu führen, dass Einzahlungen verlorengehen. 

public class Konto1 {
    private int saldo;

    public void einzahlen(int betrag) {
        saldo = saldo + betrag;
    }
}
