package bsp_14_threads;

// Minimales Beispiel für eine Konstellation, bei der es zu einem Deadlock kommen kann

public class Konto2 {
    private int saldo;

    public synchronized void umbuchenAuf(Konto2 ziel, int betrag) {
        synchronized (ziel) {
            this.saldo = this.saldo - betrag;
            ziel.saldo = ziel.saldo + betrag;
        }
    }
}
