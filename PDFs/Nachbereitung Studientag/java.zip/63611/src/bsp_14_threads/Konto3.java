package bsp_14_threads;

// Beseitigung des Dedlock-Problems

public class Konto3 {
    private int saldo;

    private final int kontoNummer;

    public Konto3(int kontoNummer) {
        this.kontoNummer = kontoNummer;
    }

    public void umbuchenAuf(Konto3 ziel, int betrag) {
        Konto3 kleiner = kontoNummer <= ziel.kontoNummer ? this : ziel;
        Konto3 groesser = kontoNummer > ziel.kontoNummer ? this : ziel;
        synchronized (kleiner) {
            synchronized (groesser) {
                this.saldo = this.saldo - betrag;
                ziel.saldo = ziel.saldo + betrag;
            }
        }
    }
}
