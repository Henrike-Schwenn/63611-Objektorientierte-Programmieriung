package bsp_14_threads;

import java.awt.*;
import java.awt.event.*;

public class Test {
    public static void main(String[] args) {
        new TestFrame();
    }
}

class ThreadTest implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent ae) {
        starteLangwierigeBerechnung();
//        starteLangwierigeBerechnungInNeuemThread();
    }

    void starteLangwierigeBerechnung() {
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    void starteLangwierigeBerechnungInNeuemThread() {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                starteLangwierigeBerechnung();
            }
        });
        t.setPriority(Thread.NORM_PRIORITY);
        t.start();
//        t.run();
    }

}

class TestFrame extends Frame {
    public TestFrame() {

        // closing mechanism
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        Button button = new Button("Start");
        button.addActionListener(new ThreadTest());
        add(button);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
