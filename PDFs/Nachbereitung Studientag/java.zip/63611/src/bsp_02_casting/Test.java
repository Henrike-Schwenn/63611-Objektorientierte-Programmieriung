package bsp_02_casting;

public class Test {
    public static void main(String[] args) {
        
        Object o1 = "Ein String";
        System.out.println(o1.name);
        
        Person p1 = (Person) o1;
        System.out.println(p1.name);

        String s = "Ein String";
        Person p2 = (Person) s;

        Person p3 = new Person();
        Printable pr = (Printable) p3; 
        pr.print();
        
        Object o = (Person) new Object();
    }
}

class Person {
    String name;

    String prename;
}

interface Printable {
    void print();
}
