package bsp_16_arraystoreexception;

public class ArrayStoreExceptionTest {
    public static void main(String[] args) {
        Student[] s = new Student[2];
        Person[] p = s;
        p[0] = new Person();
    }
}

class Person {
}

class Student extends Person {
}
