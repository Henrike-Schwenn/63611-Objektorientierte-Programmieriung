package bsp_13_enums;

public class Test1 {
    public static void main(String[] args) {
        EinTag t = new EinTag(Wochentag.Dienstag);
        t.setTag(t.getTag().naechsterTag());
        System.out.println(t.getTag());

        System.out.println(Wochentag.valueOf("Sonntag"));
        System.out.println(Wochentag.valueOf("Feiertag"));
    }
}

class EinTag {

    private Wochentag aktTag;

    public EinTag(Wochentag aktTag) {
        this.aktTag = aktTag;
    }

    public Wochentag getTag() {
        return aktTag;
    }

    public void setTag(Wochentag tag) {
        aktTag = tag;
    }
}

enum Wochentag {
    Montag, Dienstag, Mittwoch, Donnerstag, Freitag, Samstag, Sonntag;

    public Wochentag naechsterTag() {
        return values()[(ordinal() + 1) % 7];
    }

    public Wochentag vorhergehenderTag() {
        return values()[(ordinal() + 6) % 7];
    }
}
