package bsp_13_enums;

import java.util.Arrays;

public class Test2 {
    public static void main(String[] args) {
        System.out.println(Arrays.toString(Planet.values()));
    }
}

enum Planet {
    // Planeten in der Reihenfolge ihres Abstands zur Sonne
    MERKUR(0), VENUS(0), ERDE(1), MARS(2), JUPITER(79), SATURN(62), URANUS(27), NEPTUN(14);

    private final int numberOfMoons;

    private Planet(int numberOfMoons) {
        System.out.println("Planet erzeugt: " + this);
        this.numberOfMoons = numberOfMoons;
    }

    public int getNumberOfMoons() {
        return numberOfMoons;
    }
}