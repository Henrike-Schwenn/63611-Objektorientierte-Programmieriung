package bsp_19_fragile_base_class;

import java.util.*;

class IntegerBehaelter {
    ArrayList<Integer> content = new ArrayList<Integer>();

    public void add(int anInt) {
        content.add(anInt); // Autoboxing
    }

//    // erste Implementierung
//    public void addAll(Collection<Integer> someInts) {
//        for (Integer i : someInts) {
//            add(i);
//        }
//    }
    
//     Neue Implementierung
    public void addAll(Collection<Integer> someInts) {
        content.addAll(someInts);
    }
}

class AddierenderIntegerBehaelter extends IntegerBehaelter {
    private int summe;
    
    @Override
    public void add(int anInt) {
        super.add(anInt);
        summe += anInt;
    }
    
    int getSumme() {
        return summe;
    }
}

public class Test {
    public static void main(String[] args) {
        AddierenderIntegerBehaelter behaelter = new AddierenderIntegerBehaelter();
        behaelter.add(10);
        behaelter.add(3);
        ArrayList<Integer> list = new ArrayList<Integer>();
        list.add(3);
        list.add(1);
        behaelter.addAll(list);
        System.out.println(behaelter.getSumme()); // richtiges Ergebnis: 17
    }
}