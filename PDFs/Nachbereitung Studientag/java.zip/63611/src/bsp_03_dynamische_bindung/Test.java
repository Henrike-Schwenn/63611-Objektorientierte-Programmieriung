package bsp_03_dynamische_bindung;

public class Test {
    public static void main(String[] args) {
        Super s = new Sub();
        s.m();
    }
    
    static void x(Super s) {
        s.m();
    }
}

class Super {
    public void m() {
        System.out.println("Methode m von Super");
    }
}

class Sub extends Super {
    public void m() {
        System.out.println("Methode m von Sub");
    }
}