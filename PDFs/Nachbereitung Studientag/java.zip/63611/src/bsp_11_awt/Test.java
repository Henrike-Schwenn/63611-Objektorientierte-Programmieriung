package bsp_11_awt;

import java.awt.*;
import java.awt.event.*;

public class Test {
    public static void main(String[] args) {
        new MyFrame();
    }
}

class MyFrame extends Frame {

    private Panel colorPanel;

    private boolean isRed;

    public MyFrame() {
        colorPanel = new Panel();
        setPanelColor();
        add(colorPanel);

        Button switchButton = new Button("Switch color");
        switchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                isRed = !isRed;
                setPanelColor();
            }
        });
        add(switchButton, BorderLayout.SOUTH);

        // closing mechanism
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        setSize(300, 300);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void setPanelColor() {
        colorPanel.setBackground(isRed ? Color.RED : Color.GREEN);
    }
}