package bsp_07_konstruktoren_2;

public class Test {
    public static void main(String[] args) {
        new Sub();
    }
}

class Super {
    Super() {
        System.out.println("Super-Konstruktor");
        this.m();
    }
    
    void m() {
        System.out.println("Methode m() von Super");
    }
}

class Sub extends Super {
    
    Person p = new Person();
    
    Sub() {
        System.out.println("Sub-Konstruktor");
        m();
    }

    @Override
    void m() {
        System.out.println("Methode m() von Sub");
        System.out.println(p.getName());
    }
}

class Person {
    String getName() {
        return "Müller-Lüdenscheidt";
    }
}