package bsp_05_statische_bindung_von_attributen;

public class Test {
    public static void main(String[] args) {
        Super s = new Sub();
        System.out.println(s.a);
        System.out.println(s.m1());
//        System.out.println(new Sub().m2());
    }
}

class Super {
    String a = "Super-Attribut";

    String m1() {
        return a;
    }

    String x() {
        return a;
    }
}

class Sub extends Super {
    String a = "Sub-Attribut";

    String m1() {
        return a;
    }

    String m2() {
        return x();
    }
}
