package bsp_23_ojektgeflecht;

public class Main {

    Foo f;

    public Main(Foo f) {
        this.f = f;
    }

    public static void main(String[] args) {
        Foo u = new Foo();
        Main m = new Main(u);
        Foo v = new Foo();
        Foo w = new Foo(u, v, null);

        w.a.b = v;
        v.a = u.b;
        m.f.b = w.c;
        u.b.a = null;
    }
}

class Foo {
    Foo a;

    Foo b;

    Foo c;

    public Foo(Foo a, Foo b, Foo c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public Foo() {

    }
}
