package bsp_08_abstrakte_klassen;

public class Test {
    public static void main(String[] args) {
        Abstrakt a = new Konkret2();
        a.komplexeMethode();
    }
}

abstract class Abstrakt {
    void komplexeMethode() {
        int x = this.einfacheTeilaufgabe();
        int y = x + 1; // Hier finden eigentlich komplexe Vorgänge statt, eben das, was für alle Subklassen gleich sein soll
        System.out.println(y);
    }
    
    abstract int einfacheTeilaufgabe();
}

class Konkret1 extends Abstrakt {
    @Override
    int einfacheTeilaufgabe() {
        return 0;
    }
}

class Konkret2 extends Abstrakt {
    @Override
    int einfacheTeilaufgabe() {
        return 42;
    }  
}