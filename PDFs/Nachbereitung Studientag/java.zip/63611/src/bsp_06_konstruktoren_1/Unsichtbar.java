package bsp_06_konstruktoren_1;

class Unsichtbar {
    public static void main(String[] args) {
        Sub s = new Sub(3);
        System.out.println(s);
    }
}

class Super {
    private int a = 42;

    public Super(int a) {
        this.a = a;
    }

    public Super() {
    };

    @Override
    public String toString() {
        return "a=" + a;
    }
}

class Sub extends Super {
    private int b;
    private int c;

    public Sub(int b, int c) {
        this.b = b;
        this.c = c;
    }

    public Sub(int b) {
        this(b, 7);
    }

    @Override
    public String toString() {
        return super.toString() + " b=" + b + " c=" + c;
    }
}