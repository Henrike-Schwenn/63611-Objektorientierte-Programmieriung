package bsp_06_konstruktoren_1;

public class Test {
    public static void main(String[] args) {
        Lebewesen l = new Lebewesen();
        Person p0 = new Person();
        Person p1 = new Person("Meier");
        Person p2 = new Student("Schmidt", 12345678);
        Person p3 = new Professor("Sonnenschein", 6500);
    }
}

class Lebewesen {

}

class Person extends Lebewesen {

    private String name;

    Person(String name) {
        this.name = name;
    }
}

class Student extends Person {

    private int matrikelNummer;

    Student(String name, int matrikelNummer) {
        super(name);
        this.matrikelNummer = matrikelNummer;
    }
}

class Professor extends Person {
    private int gehalt;

    Professor(String name, int gehalt) {
        this.gehalt = gehalt;
    }
}