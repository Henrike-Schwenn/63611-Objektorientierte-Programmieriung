package bsp_18_wildcards;

import java.util.*;

interface ImportExportList<E> extends List<E> {
    public void importFrom(List<? extends E> sourceList);
    public void exportTo(List<? super E> targetList);
}

class ImportExportListImpl<T> extends ArrayList<T>implements ImportExportList<T> {

    @Override
    public void importFrom(List<? extends T> sourceList) {
        for (T elem : sourceList) {
            this.add(elem);
        }
    }

    @Override
    public void exportTo(List<? super T> targetList) {
        for (T elem : this) {
            targetList.add(elem);
        }
    }
}

public class ImportExportListTest {
    public static void main(String[] args) {
        List<Student> studentenListe = new LinkedList<Student>();
        studentenListe.add(new Student());
        studentenListe.add(new Student());
        studentenListe.add(new Student());

        List<Professor> professorenListe = new ArrayList<Professor>();
        professorenListe.add(new Professor());
        professorenListe.add(new Professor());

        List<Lebewesen> lebewesenListe = new ArrayList<Lebewesen>();
        lebewesenListe.add(new Elefant());

        ImportExportListImpl<Person> meineListe = new ImportExportListImpl<Person>();

        meineListe.importFrom(studentenListe);
        meineListe.importFrom(professorenListe);
        meineListe.add(new Lokfuehrer());
        meineListe.exportTo(lebewesenListe);

        for (Lebewesen wesen : lebewesenListe) {
            System.out.println(wesen);
        }
    }
}

class Student extends Person {
}

class Professor extends Person {
}

class Lokfuehrer extends Person {
}

class Person extends Lebewesen {
}

class Lebewesen {
}

class Tier extends Lebewesen {
}

class Elefant extends Tier {
}