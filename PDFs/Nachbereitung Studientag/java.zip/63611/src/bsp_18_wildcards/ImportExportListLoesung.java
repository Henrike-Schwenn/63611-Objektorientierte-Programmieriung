package bsp_18_wildcards;

import java.util.List;

/**
 * An abstract collection with import/export methods.
 * 
 * @author Michael Paap
 * 
 * @param <T>
 *            the type parameter of this list
 */
public abstract class ImportExportListLoesung<T> implements List<T> {

    /**
     * Imports all elements of a source list into this list.
     * 
     * @param sourceList
     *            the list whose elements are imported
     */
    void importFrom(List<? extends T> sourceList) {
        for (T elem : sourceList) {
            this.add(elem);
        }
    }

    /**
     * Exports all element of this list to a target list.
     * 
     * @param targetList
     *            the list to which the elements are exported
     */
    void exportTo(List<? super T> targetList) {
        for (T elem : this) {
            targetList.add(elem);
        }
    }
}