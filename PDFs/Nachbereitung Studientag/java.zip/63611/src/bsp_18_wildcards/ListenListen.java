package bsp_18_wildcards;

import java.util.ArrayList;
import java.util.List;

public class ListenListen {
    public static void main(String[] args) {
        List<Tiger> tigerListe = new ArrayList<>();
        tigerListe.add(new Tiger());
        tigerListe.add(new Tiger());
        tigerListe.add(new Tiger());
        List<Giraffe> giraffenListe = new ArrayList<>();
        giraffenListe.add(new Giraffe());
        giraffenListe.add(new Giraffe());
        List<Ameisenbär> ameisenbärenListe = new ArrayList<>();
        ameisenbärenListe.add(new Ameisenbär());
        ameisenbärenListe.add(new Ameisenbär());
        ameisenbärenListe.add(new Ameisenbär());
        ameisenbärenListe.add(new Ameisenbär());
        
        List<List<? extends ZooTier>> tierListenListe = new ArrayList<List<? extends ZooTier>>();
        tierListenListe.add(tigerListe);
        tierListenListe.add(giraffenListe);
        tierListenListe.add(ameisenbärenListe);

        for (List<? extends ZooTier> tierListe : tierListenListe) {
            for (ZooTier tier : tierListe) {
                tier.füttere();
            }
        }
    }
}

class ZooTier {
    void füttere() {
        System.out.println(getClass().getSimpleName() + " gefüttert.");
    }
}

class Tiger extends ZooTier {
}

class Giraffe extends ZooTier {
}

class Ameisenbär extends ZooTier {
}