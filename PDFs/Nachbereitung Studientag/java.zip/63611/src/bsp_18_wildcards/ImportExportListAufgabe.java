package bsp_18_wildcards;

// 1. Durch welche Typen sollten die $$$ ersetzt werden?
// 2. Implementieren Sie die beiden Methoden.

import java.util.List;

/**
 * An abstract collection with import/export methods.
 * 
 * @author Michael Paap
 * 
 * @param <T>
 *            the type parameter of this list
 */
public abstract class ImportExportListAufgabe<T> implements List<T> {

    /**
     * Imports all elements of a source list into this list.
     * 
     * @param sourceList
     *            the list whose elements are imported
     */
    void importFrom($$$ sourceList) {
        // Implementierung        
    }

    /**
     * Exports all element of this list to a target list.
     * 
     * @param targetList
     *            the list to which the elements are exported
     */
    void exportTo($$$ targetList) {
        // Implementierung
    }
}