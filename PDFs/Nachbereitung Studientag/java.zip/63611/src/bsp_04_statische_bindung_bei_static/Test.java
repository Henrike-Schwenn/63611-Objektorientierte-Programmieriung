package bsp_04_statische_bindung_bei_static;

public class Test {

    public static void main(String[] args) {
        Super s1 = new Super();
        s1.m();
        Super s2 = new Sub();
        s2.m();
        ((Sub) s2).m();
    }
}

class Super {
    public static void m() {
        System.out.println("Methode m von Super");
    }
}

class Sub extends Super {
    public static void m() {
        System.out.println("Methode m von Sub");
    }
}