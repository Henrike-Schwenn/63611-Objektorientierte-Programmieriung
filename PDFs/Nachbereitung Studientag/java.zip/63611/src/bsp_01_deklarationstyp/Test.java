package bsp_01_deklarationstyp;

public class Test {
    public static void main(String[] args) {
        Super s = new Sub();
        s.m();
    }
}

class Super {

}

class Sub extends Super {
    void m() {
        System.out.println("Hello");
    }
}
