package bsp_21_listener;

import java.util.ArrayList;
import java.util.List;

public class FilterTest {
    public static void main(String[] args) {
        ArrayList<Person> source = new ArrayList<Person>();
        source.add(new Person("Alice", 56.3));
        source.add(new Person("Joe", 77.0));
        source.add(new Person("Bob", 90.2));
        source.add(new Person("Jenny", 44.2));
        source.add(new Person("Anna", 51.9));
        source.add(new Person("Peter", 84.3));
        source.add(new Person("George", 69.7));

        Filter<Person> personFilter = new Filter<>(source);

        List<Person> shortNameList1 = personFilter.filter(new FilterPredicate<Person>() {
            @Override
            public boolean isMatching(Person p) {
                return p.getName().length() < 5;
            }
        });
        for (Person person : shortNameList1) {
            System.out.println(person.getName());
        }
        System.out.println("----------------------------");
        List<Person> shortNameList2 = personFilter.filter(p -> p.getName().length() < 5);
        for (Person person : shortNameList2) {
            System.out.println(person.getName());
        }
        System.out.println("----------------------------");
        List<Person> lightweightPersonList = personFilter.filter(p -> p.getWeight() < 60);
        for (Person person : lightweightPersonList) {
            System.out.println(person);
        }

    }
}

class PersonFilterPredicate1 implements FilterPredicate<Person> {
    @Override
    public boolean isMatching(Person candidate) {
        return candidate.getWeight() < 60.0;
    }
}

interface FilterPredicate<T> {
    boolean isMatching(T candidate);
}

class Filter<T> {
    private List<T> sourceList;

    public Filter(List<T> sourceList) {
        this.sourceList = sourceList;
    }

    List<T> filter(FilterPredicate<T> filterPredicate) {
        ArrayList<T> resultList = new ArrayList<T>();
        for (T elem : sourceList) {
            if (filterPredicate.isMatching(elem)) {
                resultList.add(elem);
            }
        }
        return resultList;
    }
}

class Person {
    private String name;
    private double weight;

    public Person(String name, double weight) {
        this.name = name;
        this.weight = weight;
    }

    public String getName() {
        return name;
    }

    public double getWeight() {
        return weight;
    }

    @Override
    public String toString() {
        return name + ": " + weight;
    }
}