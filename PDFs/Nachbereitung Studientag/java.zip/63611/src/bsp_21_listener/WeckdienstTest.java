package bsp_21_listener;

import java.text.SimpleDateFormat;
import java.util.*;

public class WeckdienstTest {
    public static void main(String[] args) {
        // Wir erzeugen einen Weckdienst für eine bestimmte Uhrzeit
        Weckdienst weckdienst = new Weckdienst("01:52");

        // Wir erzeugen einen Hotelgast und melden ihn beim Weckdienst an
        WeckdienstKunde gast = new HotelGast();
        weckdienst.anmelden(gast);

        // Und nun noch ein zweiter WeckdienstKunde, diesmal ein Exemplar einer anonymen methodenlokalen Klasse
        weckdienst.anmelden(new WeckdienstKunde() {
            @Override
            public void wecke(WeckEreignis ereignis) {
                System.out.println("SEUFZ. Auch Anonymität schützt nicht vorm Aufstehenmüssen.");
            }
        });

        weckdienst.arbeite();
    }
}

interface WeckdienstKunde {
    void wecke(WeckEreignis ereignis);
}

class Weckdienst {

    private String weckZeit;

    public Weckdienst(String weckZeit) {
        this.weckZeit = weckZeit;
    }

    private List<WeckdienstKunde> kunden = new ArrayList<WeckdienstKunde>();

    public void anmelden(WeckdienstKunde kunde) {
        kunden.add(kunde);
        System.out.println("Kunde angemeldet.");
    }

    public void arbeite() {
        // Bitte beachten: Dies ist KEIN beispielhaftes Arbeiten mit Datum/Uhrzeit,
        // sondern schnell und schnutzig hingeschrieben, damit Sie sehen, dass zur
        // Weckzeit wirklich etwas passiert.
        System.out.println("Weckdienst scharf geschaltet.");
        boolean ausgefuehrt = false;
        while (!ausgefuehrt) {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
            String zeit = sdf.format(new Date());
            if (zeit.equals(weckZeit)) {
                ausgefuehrt = true;
                weckeAlleKunden();
            }
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void weckeAlleKunden() {
        WeckEreignis ereignis = new WeckEreignis(this, weckZeit);
        for (WeckdienstKunde kunde : kunden) {
            kunde.wecke(ereignis);
        }
    }
}

class HotelGast implements WeckdienstKunde {

    @Override
    public void wecke(WeckEreignis ereignis) {
        System.out.println("Oh, schon " + ereignis.uhrzeit
                + " Uhr! Dann will ich mal aufstehn und schauen, was das Frühstücksbuffet bietet.");
    }
}

class WeckEreignis {
    public final Weckdienst source;

    public final String uhrzeit;

    public WeckEreignis(Weckdienst source, String uhrzeit) {
        this.source = source;
        this.uhrzeit = uhrzeit;
    }
}