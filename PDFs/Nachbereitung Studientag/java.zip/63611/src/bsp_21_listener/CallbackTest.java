package bsp_21_listener;

import java.awt.*;
import java.awt.event.*;

public class CallbackTest {
    public static void main(String[] args) {

        // Version 1
        Button b1 = new Button("Test 1");
        b1.addActionListener(new MyActionListener());

        // Version 2
        Button b2 = new MyActionButton("Test 2");

        // Version 3
        Button b3 = new Button("Test 3");
        b3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                System.out.println("Klicked " + ae.getActionCommand());
            }
        });

        // Version 4
        Button b4 = new ActionButton("Test 4") {
            @Override
            public void actionPerformed(ActionEvent ae) {
                System.out.println("Klicked " + ae.getActionCommand());
            }
        };

        // Version 5 (seit Java 8 moeglich)
        Button b5 = new Button("Test 5");
        b5.addActionListener(ae -> {
            System.out.println("Klicked " + ae.getActionCommand());
        });
        
        Frame f = new Frame();
        f.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        f.setLayout(new GridLayout(5, 1));
        f.add(b1);
        f.add(b2);
        f.add(b3);
        f.add(b4);
        f.add(b5);
        f.pack();
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }
}

class MyActionListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent ae) {
        System.out.println("Klicked " + ae.getActionCommand());
    }
}

abstract class ActionButton extends Button implements ActionListener {
    public ActionButton(String text) {
        super(text);
        addActionListener(this);
    }
}

class MyActionButton extends ActionButton {
    public MyActionButton(String text) {
        super(text);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        System.out.println("Klicked " + ae.getActionCommand());
    }
}