package bsp_20_quadrat_rechteck_mit_offener_rekursion;

abstract class Rechteck3 {
    abstract int laenge();

    abstract int breite();

    int flaeche() {
        return laenge() * breite();
    }

    int umfang() {
        return (laenge() + breite()) * 2;
    }
}

final class Quadrat3 extends Rechteck3 {
    int laenge;

    @Override
    int laenge() {
        return laenge;
    }

    @Override
    int breite() {
        return laenge;
    }
}

final class NichtquadratischesRechteck extends Rechteck3 {

    int laenge;

    int breite;

    @Override
    int laenge() {
        return laenge;
    }

    @Override
    int breite() {
        return breite;
    }
}
