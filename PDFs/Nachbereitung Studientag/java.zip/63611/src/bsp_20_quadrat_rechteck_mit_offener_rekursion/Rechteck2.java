package bsp_20_quadrat_rechteck_mit_offener_rekursion;

class Rechteck2 {
    int breite;

    int laenge;

    int flaeche() {
        return laenge * breite;
    }

    int umfang() {
        return (laenge + breite) * 2;
    }
}

class Quadrat2 extends Rechteck2 {
    // hier hat Quadrat ein überflüssiges Attribut und wir müssen sicherstellen
    // dass immer laenge == breite
}
