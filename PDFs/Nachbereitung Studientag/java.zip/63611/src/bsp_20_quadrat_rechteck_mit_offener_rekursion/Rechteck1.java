package bsp_20_quadrat_rechteck_mit_offener_rekursion;

class Quadrat1 {
    int laenge;
    
    int flaeche() {
        return laenge * laenge;
    }
    
    int umfang() {
        return laenge * 4;
    }
}

class Rechteck1 extends Quadrat1 {
    int breite;
    
    @Override
    int flaeche() {
        return laenge * breite;
    }
    
    @Override
    int umfang() {
        return (laenge + breite) * 2;
    }
}
